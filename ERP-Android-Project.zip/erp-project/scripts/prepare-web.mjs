import { cp, mkdir, rm, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve('.');
const www = resolve(root, 'www');
await rm(www, { recursive: true, force: true });
await mkdir(resolve(www, 'vendor'), { recursive: true });
await cp(resolve(root, 'ERP-App.html'), resolve(www, 'index.html'));

const files = [
  ['node_modules/react/umd/react.production.min.js', 'vendor/react.production.min.js'],
  ['node_modules/react-dom/umd/react-dom.production.min.js', 'vendor/react-dom.production.min.js'],
  ['node_modules/@babel/standalone/babel.min.js', 'vendor/babel.min.js'],
  ['node_modules/xlsx/dist/xlsx.full.min.js', 'vendor/xlsx.full.min.js']
];
for (const [src, dst] of files) {
  if (!existsSync(resolve(root, src))) throw new Error(`Missing dependency: ${src}`);
  await cp(resolve(root, src), resolve(www, dst));
}

let html = await readFile(resolve(www, 'index.html'), 'utf8');
// Android build is offline-first. Existing Apps Script/JSONP UI is retained for now,
// but no network operation is allowed by the Android WebView unless a future sync layer is added.
html = html.replace(/<script src="vendor\/babel\.min\.js"><\/script>/, '<script src="vendor/babel.min.js"></script>');
await writeFile(resolve(www, 'index.html'), html);
console.log('Prepared offline web bundle in www/');
