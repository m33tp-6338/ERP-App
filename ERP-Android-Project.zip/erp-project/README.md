# Business Ledger ERP — Android-ready project

This project packages the current `ERP-App.html` as a private Android application using Capacitor.

## Master file

`ERP-App.html` is the only application source file you should normally edit. Do not edit `www/` or `android/` by hand.

## Offline-first behavior

The runtime dependencies are bundled into the APK at build time. The app does not need a CDN, Google Fonts, or a web server to start.

The existing ERP data remains in the app's local storage. Do not clear app storage when installing an update.

## Current sync status

Google Apps Script/Google Sheets sync is not part of the Android sync architecture yet. The existing source UI is retained for compatibility, but the future Drive/Excel sync should be implemented as a dedicated, explicit user-triggered feature.

## Build

```bash
npm install
npm run build:android
```

Then use Android Studio/Gradle to build the APK.
